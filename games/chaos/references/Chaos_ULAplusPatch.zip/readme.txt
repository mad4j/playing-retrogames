Chaos: 256-colour edition for ULAPlus
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  This archive contains the source code, Makefile and tools used to convert
Chaos to take advantage of the 256-colour ULA. 

  This isn't just a simple tapefile containing a palette, I'm afraid, because
it patches the game engine in various ways to take full advantage of the new
ULA. To build:

1. Install the taptools, version 1.0.5 or later:
	<http://www.seasip.info/ZX/unix.html>
2. Install Udo Munk's Z80ASM:
	<http://www.unix4fun.org/z80pack/index.html>
3. Drop a .SNA snapshot of Chaos into this directory.
4. Type 'make'.
5. If all went well, you should now have a nice shiny chaos256.tap.

  Note: I have been very restrained and not patched any of the other Chaos
logic, so the game still retains each and every bug of the original. The 
new code occupies a certain amount of space in the symbol table, so any 
other patches that use this table may no longer work.

  Second note: If anyone wants to design a better title screen, or has any
other suggestions, please let me know.

John Elliott -- jce@seasip.demon.co.uk

