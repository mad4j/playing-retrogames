#include <stdio.h>

int main(int argc, char **argv)
{
	int c;

	while ((c = getchar()) != EOF)
	{
		printf("\tDEFB\t%03xh\n", c);
	}
	return 0;
}
